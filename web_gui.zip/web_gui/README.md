# Easy generation of scATACpipe configuration file with web GUI
Implemented with pure HTML, JS, and CSS, can be used locally without backend server.
